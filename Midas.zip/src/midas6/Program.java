package midas6;

public class Program {
	public static void main(String[] args) {
		
	}
}
